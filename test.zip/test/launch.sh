#!/bin/bash

idle-python3.5 -r final.py
